# Ensure epel is enabled by yum-config-manager --enable epel
# Installing composer

whereis composer > /dev/null 2>&1
if [ $? -eq 0 ]
then
  echo "Composer already installed"
  echo "You may need to rename composer.phar to composer in /usr/bin"
else
  curl -sS https://getcomposer.org/installer | sudo php
  mv composer.phar /usr/local/bin/composer
  ln -s /usr/local/bin/composer /usr/bin/composer
  composer install
fi

other_packages=("html2text.x86_64" "jpegoptim.x86_64" "poppler.x86_64" "poppler-utils.x86_64")
for i in "${other_packages[@]}"
do
  yum list installed | grep $i > /dev/null 2>&1
  if [ $? -eq 0 ]
  then
    echo "$i already installed"
  else
    yum install "$i" -y
  fi
done
