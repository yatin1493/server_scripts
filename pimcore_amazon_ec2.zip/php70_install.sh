# Ensure epel is enabled by yum-config-manager --enable epel
# Install PHP 7.0 and packages
php_packages=("php70.x86_64" "php70-bcmath.x86_64" "php70-cli.x86_64" "php70-common.x86_64" "php70-dba.x86_64" "php70-fpm.x86_64" "php70-gd.x86_64" "php70-imap.x86_64" "php70-json.x86_64" "php70-mbstring.x86_64" "php70-mcrypt.x86_64" "php70-mysqlnd.x86_64" "php70-opcache.x86_64" "php70-pdo.x86_64" "php70-pecl-imagick.x86_64" "php70-pecl-imagick-devel.x86_64" "php70-pecl-memcache.x86_64" "php70-pecl-redis.x86_64" "php70-xml.x86_64" "php70-zip.x86_64")
for i in "${php_packages[@]}"
do
  yum list installed | grep $i > /dev/null 2>&1
  if [ $? -eq 0 ]
  then
    echo "$i already installed"
  else
    yum install "$i" -y
  fi
done

