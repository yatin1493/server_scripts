# Ensure epel is enabled by yum-config-manager --enable epel
# Install Development Tools(gcc gcc++), tcl for make test, and redis

yum grouplist Development\ tools installed|grep Installed > /dev/null 2>&1
if [ $? -eq 0 ]
then
  echo "Development Tools already Installed"
else
  yum groupinstall "Development Tools" -y
fi

# for running make test on installing redis
yum list installed|grep tcl.x86_64 > /dev/null 2>&1
if [ $? -eq 0 ]
then
  echo "tcl.x86_64 already installed"
else
  yum install tcl.x86_64 -y
fi

# installing redis

redis-server -v
if [ $? -eq 0 ]
then
 echo "Redis Server already installed"
else
 cd /opt
 mkdir redis
 cd redis
 wget http://download.redis.io/releases/redis-3.2.9.tar.gz
 tar xzf redis-3.2.9.tar.gz
 cd redis-3.2.9/deps
 make hiredis jemalloc linenoise lua geohash-int
 cd ..
 make install
 make test
 cp /etc/bashrc /etc/bashrc.bkp
 echo "# Yatin setted env variables" >> /etc/bashrc
 echo "PATH=\"/usr/local/bin:\$PATH\"" >> /etc/bashrc
 echo "PATH=\"/opt/redis/redis-3.2.9/src:\$PATH\"" >> /etc/bashrc
fi

