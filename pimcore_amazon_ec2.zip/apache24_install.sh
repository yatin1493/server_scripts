# Ensure epel is enabled by yum-config-manager --enable epel

yum list installed|grep httpd24 > /dev/null 2>&1
if [ $? -eq 0 ]
then
  echo "Apache 2.4 already Installed"
else
  yum install httpd24.x86_64
  /etc/init.d/httpd status
  chkconfig httpd on
fi
