# Ensure epel is enabled by yum-config-manager --enable epel
# Install MYSQL56
yum list installed|grep mysql56 > /dev/null 2>&1
if [ $? -eq 0 ]
then
  echo "MYSQL5.6 already Installed"
else
  sudo yum-config-manager --enable epel
  yum install mysql56-server.x86_64 -y
  /etc/init.d/mysqld start
  chkconfig mysqld on
  mysql_secure_installation
fi
#echo "CREATING DATABASE pimcoredb IF NOT ALREADY EXISTS......."
#echo "create database if not exists pimcoredb charset=utf8mb4;" | mysql -uroot -p
