# Pimcore: 4.6
# Apache: 2.4
# PHP: 7.0
# MYSQL : 5.6
# Redis: 3.2.9
# PHP Extensions: bcmath, cli, dba, fpm, gd, imap, json, mbstring, mcrypt, mysqlnd, opcache, pdo, pecl-imagick, pecl-imagick-devel
# pecl-memcache, pecl-redis, simplexml, zip
# Other: composer, html2text, jpegoptim, pdftotext(poppler)
# Database name: pimcoredb
# Database username: root

PROJ_NAME="myproj"

sudo yum-config-manager --enable epel

yum install httpd24.x86_64

/etc/init.d/httpd status

chkconfig httpd on

yum install mysql56-server.x86_64

/etc/init.d/mysqld start

chkconfig mysqld on

mysql_secure_installation

echo "create database pimcoredb charset=utf8mb4;" | mysql -uroot -p

yum install php70.x86_64 php70-bcmath.x86_64 php70-cli.x86_64 php70-common.x86_64 php70-dba.x86_64 php70-fpm.x86_64 php70-gd.x86_64 php70-imap.x86_64 php70-json.x86_64 php70-mbstring.x86_64 php70-mcrypt.x86_64 php70-mysqlnd.x86_64 php70-opcache.x86_64 php70-pdo.x86_64 php70-pecl-imagick.x86_64 php70-pecl-imagick-devel.x86_64 php70-pecl-memcache.x86_64 php70-pecl-redis.x86_64 php70-xml.x86_64 php70-zip.x86_64

yum groupinstall "Development Tools"
yum install tcl.x86_64 # for running make test on installing redis

cd /home/ec2-user
mkdir redis
cd redis


wget http://download.redis.io/releases/redis-3.2.9.tar.gz
tar xzf redis-3.2.9.tar.gz
cd redis-3.2.9/deps
make hiredis jemalloc linenoise lua geohash-int
cd ..
make install
make test

cp /etc/bashrc /etc/bashrc.bkp
echo "# Yatin setted env variables" >> /etc/bashrc
echo "PATH=\"/usr/local/bin:\$PATH\"" >> /etc/bashrc
echo "PATH=\"/home/ec2-user/redis/redis-3.2.9/src:\$PATH\"" >> /etc/bashrc

# Now type reddis-server and hit and redis server will open. To exit type exit

cp /etc/httpd/conf/httpd.conf /etc/httpd/conf/httpd.conf.bkp
# set your project directory name in DocumentRoot and correspond to that path add these lines, suppose path is /var/www/html/myproj then it is set as

#DocumentRoot /var/www/html/myproj
#<Directory "/var/www/html/myproj">
#   AllowOverride All
#</Directory>

# and restart httpd

mkdir -p "/var/www/html/${PROJ_NAME}"
cd "/var/www/html/${PROJ_NAME}"
wget https://www.pimcore.org/download/pimcore-latest.zip
unzip pimcore-latest.zip
rm -f pimcore-latest.zip
cd ..
chmod -R 755 "${PROJ_NAME}"
chown -R apache:apache "${PROJ_NAME}"


curl -sS https://getcomposer.org/installer | sudo php
mv composer.phar /usr/local/bin/composer
ln -s /usr/local/bin/composer /usr/bin/composer
composer install

yum install html2text.x86_64
yum install jpegoptim.x86_64
yum install poppler.x86_64
yum install poppler-utils.x86_64


