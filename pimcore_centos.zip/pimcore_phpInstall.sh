sudo rpm -Uvh https://dl.fedoraproject.org/pub/epel/epel-release-latest-7.noarch.rpm
sudo rpm -Uvh https://mirror.webtatic.com/yum/el7/webtatic-release.rpm

yum install php70w.x86_64 php70w-bcmath.x86_64 php70w-cli.x86_64 php70w-common.x86_64 php70w-dba.x86_64 php70w-fpm.x86_64 php70w-gd.x86_64 php70w-imap.x86_64 php70w-json.x86_64 php70w-mbstring.x86_64 php70w-mcrypt.x86_64 php70w-mysqlnd.x86_64 php70w-opcache.x86_64 php70w-pdo.x86_64 php70w-pecl-imagick.x86_64 php70w-pecl-imagick-devel.x86_64 php70w-pecl-memcache.x86_64 php70w-pecl-redis.x86_64 php70w-xml.x86_64 php70w-zip.x86_64 -y
