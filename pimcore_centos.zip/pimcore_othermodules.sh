yum install composer.noarch php-composer-ca-bundle.noarch php-composer-installers.noarch php70w-opcache.x86_64 php70w-pecl-apcu.x86_64 libreoffice.x86_64 perl-Image-ExifTool.noarch libpng.x86_64 libpng-devel.i686 gd.x86_64 libtiff.x86_64 libtiff-devel.x86_64 jpeginfo.x86_64 jpegoptim.x86_64 libjpeg-turbo.x86_64 libjpeg-turbo-devel.x86_64 pngcrush.x86_64 pnglite.x86_64 pnglite-devel.x86_64 libjpeg-turbo-utils.x86_64 zopfli.x86_64 html2text.x86_64 libpng-devel php70w-pecl-apcu-devel.x86_64 php70w-pecl-apcu.x86_64 php-intl

wget https://johnvansickle.com/ffmpeg/builds/ffmpeg-git-64bit-static.tar.xz

wget https://github.com/imagemin/zopflipng-bin/raw/master/vendor/linux/zopflipng -O /usr/bin/zopflipng

wget https://github.com/wkhtmltopdf/wkhtmltopdf/releases/download/0.12.4/wkhtmltox-0.12.4_linux-generic-amd64.tar.xz

wget https://github.com/imagemin/pngout-bin/raw/master/vendor/linux/x64/pngout -O /usr/bin/pngout

wget https://github.com/imagemin/advpng-bin/raw/master/vendor/linux/advpng -O /usr/bin/advpng

wget https://github.com/imagemin/mozjpeg-bin/raw/master/vendor/linux/cjpeg -O /usr/bin/cjpeg

ftp://ftp.imagemagick.org/pub/ImageMagick/ImageMagick.tar.gz
tar -xvzf ImageMagick.tar.gz
cd ImageMagick-7.0.3-9/
./configure --enable-shared
make
make install
whereis identify
/usr/local/bin/identify -version
sed -i "$ s|\-n||g" /usr/bin/pecl
pecl install imagick
when ask for Imagemagick directory, provide "/usr/local"

php -m
