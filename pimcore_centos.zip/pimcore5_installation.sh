yum install php70.x86_64 php70-bcmath.x86_64 php70-cli.x86_64 php70-common.x86_64 php70-devel.x86_64 php70-fpm.x86_64 php70-gd.x86_64 php70-imap.x86_64 php70-intl.x86_64 php70-json.x86_64 php70-ldap.x86_64 php70-mbstring.x86_64 php70-mcrypt.x86_64 php70-mysqlnd.x86_64 php70-opcache.x86_64 php70-pdo.x86_64 php70-pecl-imagick.x86_64 php70-pecl-memcache.x86_64 php70-pecl-redis.x86_64 php70-xml.x86_64 php70-snmp.x86_64 php70-zip.x86_64 php70-process.x86_64 php70-pecl-yaml.x86_64 -y

curl -sS https://getcomposer.org/installer | php
mv composer.phar /usr/bin/composer

# Installing FFMPEG

wget https://johnvansickle.com/ffmpeg/builds/ffmpeg-git-64bit-static.tar.xz
tar -Jxf ffmpeg-git-64bit-static.tar.xz
rm ffmpeg-git-64bit-static.tar.xz 
mv ffmpeg-git-20170919-64bit-static /usr/local/ffmpeg
ln -s /usr/local/ffmpeg/ffmpeg /usr/local/bin
ln -s /usr/local/ffmpeg/ffprobe /usr/local/bin/
ln -s /usr/local/ffmpeg/qt-faststart /usr/local/bin
ln -s /usr/local/ffmpeg/qt-faststart /usr/local/bin/qtfaststart

# Installing libreoffice

yum remove openoffice* libreoffice*
wget http://ftp.ussg.indiana.edu/tdf/libreoffice/stable/5.4.1/rpm/x86_64/LibreOffice_5.4.1_Linux_x86-64_rpm.tar.gz
tar -xvf LibreOffice_5.4.1_Linux_x86-64_rpm.tar.gz
cd LibreOffice_5.4.1.2_Linux_x86-64_rpm/
cd RPMS/
yum localinstall *.rpm

# Poppler Utils

yum install poppler.x86_64 poppler-utils.x86_64 -y

# wkhtmltox

wget https://github.com/wkhtmltopdf/wkhtmltopdf/releases/download/0.12.4/wkhtmltox-0.12.4_linux-generic-amd64.tar.xz
tar -xvf wkhtmltox-0.12.4_linux-generic-amd64.tar.xz
mv wkhtmltox /usr/local
ln -s /usr/local/wkhtmltox/bin/wkhtmltoimage /usr/local/bin
ln -s /usr/local/wkhtmltox/bin/wkhtmltopdf /usr/local/bin

#zopflipng

wget https://github.com/imagemin/zopflipng-bin/raw/master/vendor/linux/zopflipng -O /usr/local/bin/zopflipng
chmod 0755 /usr/local/bin/zopflipng

#pngcrush

wget https://github.com/imagemin/jpegoptim-bin/raw/master/vendor/linux/jpegoptim -O /usr/local/bin/jpegoptim
chmod 0755 /usr/local/bin/jpegoptim

#pngout

wget https://github.com/imagemin/pngout-bin/raw/master/vendor/linux/x64/pngout -O /usr/local/bin/pngout
chmod 0755 /usr/local/bin/pngout

#advpng

wget https://github.com/imagemin/advpng-bin/raw/master/vendor/linux/advpng -O /usr/local/bin/advpng
chmod 0755 /usr/local/bin/advpng

#cjpeg

wget https://github.com/imagemin/mozjpeg-bin/raw/master/vendor/linux/cjpeg -O /usr/local/bin/cjpeg
chmod 0755 /usr/local/bin/cjpeg

#exiftool

yum install perl-Image-ExifTool.noarch

# Installing Pimcore

cd /var/www/html
wget https://www.pimcore.org/download-5/pimcore-latest.zip -O pimcore-install.zip
unzip pimcore-install.zip
rm -f pimcore-install.zip 
# Make database pimcore5 and grant all(*) access to it to pimcore user


# configure PHP FPM

vim /etc/php-fpm-7.0.d/www.conf
# change user and group from apache to nginx
# ensure socket file is commented and listen set to 127.0.0.1:9000
# save and exit
/etc/init.d/php-fpm restart

# make virtualhost in nginx
# copy nginx configuration from https://www.pimcore.org/docs/5.0.0/Installation_and_Upgrade/System_Setup_and_Hosting/Nginx_Configuration.html to file /etc/nginx/conf.d/pimcore.conf
# change server 'unix:/var/run/php/pimcore5.sock;' with '127.0.0.1:9000;'
# change server name 'pimcore.loc;' with '<virtualhost_name>;'
# change root '/var/www/pimcore/web;' with '<project_root>/web;'
# set correct path of access and error log
# search for expires and comment it
# when pimcore is not installed uncomment this line '# location ~ /(app|install)\.php(/|$) {' and comment line 'location ~ ^/app\.php(/|$) {'
# when pimcore get installed do opposite of above
#save and exit
/etc/init.d/nginx restart

chmod 777 /var/www/html/var/cache # just when running first time then change it to 775
# Ensure nginx user must have right to execute file

# Install aCPU

yum install php70-pecl-apcu-devel.x86_64 -y

# Installing html2text

yum install -x python2-html2text html2text

# Installing jpegoptim

yum install jpegoptim.x86_64 -y
yum install libjpeg-turbo-devel.x86_64 libjpeg-turbo-static.x86_64 -y
cd ~
wget http://www.kokkonen.net/tjko/src/jpegoptim-1.4.1.tar.gz
tar -xzf jpeg*
cd ./jpeg*
./configure
make
make install



